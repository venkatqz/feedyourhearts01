import React from 'react'

function DonorDashboard() {
  return (
    <div>DonorPage</div>
  )
}

export default DonorDashboard