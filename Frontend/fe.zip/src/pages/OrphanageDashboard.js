import React from 'react'

function OrphanageDashboard() {
  return (
    <div>OrphanageDashboard</div>
  )
}

export default OrphanageDashboard